foo = "bar"
